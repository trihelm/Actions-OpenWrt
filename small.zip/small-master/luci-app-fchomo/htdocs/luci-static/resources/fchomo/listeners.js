'use strict';
'require baseclass';
'require form';
'require uci';
'require ui';

'require fchomo as hm';

const CBIDummyCopyValue = hm.CopyValue.extend({
	__name__: 'CBI.DummyCopyValue',

	renderWidget(/* ... */) {
		let node = hm.CopyValue.prototype.renderWidget.apply(this, arguments);

		node.firstChild.style.width = '30em';

		return node;
	},

	write: function() {}
});

class VlessEncryption {
	// origin:
	// https://github.com/XTLS/Xray-core/pull/5067
	// server:
	// https://github.com/muink/mihomo/blob/7917f24f428e40ac20b8b8f953b02cf59d1be334/transport/vless/encryption/factory.go#L64
	// https://github.com/muink/mihomo/blob/7917f24f428e40ac20b8b8f953b02cf59d1be334/transport/vless/encryption/server.go#L42
	// client:
	// https://github.com/muink/mihomo/blob/7917f24f428e40ac20b8b8f953b02cf59d1be334/transport/vless/encryption/factory.go#L12
	// https://github.com/muink/mihomo/blob/7917f24f428e40ac20b8b8f953b02cf59d1be334/transport/vless/encryption/client.go#L45
/*
{
	"method": "mlkem768x25519plus",
	"xormode": "native",
	"ticket": "600s",
	"rtt": "0rtt",
	"paddings": [ // Optional
		"100-111-1111",
		"75-0-111",
		"50-0-3333",
		...
	],
	"keypairs": [
		{
			"type": "vless-x25519",
			"server": "cP5Oy9MOpTaBKKE17Pfd56mbb1CIfp5EMpyBYqr2EG8",
			"client": "khEcQMT8j41xWmGYKpZtQ4vd8_9VWyFVmmCDIhRJ-Uk"
		},
		{
			"type": "vless-mlkem768",
			"server": "UHPx3nf-FVxF95byAw0YG025aQNw9HxKej-MiG5AhTcdW_WFpHlTVYQU5NHmXP6tmljSnB2iPmSQ29fisGxEog",
			"client": "h4sdZgCc5-ZefvQ8mZmReOWQdxYb0mwngMdl7pKhYEZZpGWHUPKAmxug87Bgj3GqSHs195QeVpxfrMLNB5Jm0Ge71Fc-A3aLpaS3C3pARbGQoquUDUEVDNwEWjQTvFpGTUV3Nddw_LlRmWN6Wqhguti9cpS6GhEmkBvBayFeHgZosuaQ1FMoAqIeQzSSSoguCZtGLUmdQjEs3zc5rwG1rNanbhtyI3QnooYvr3A0vggIkbmddjtjwYaVQdMAj9Moavc12EAUajOV91QA73RWVuhelbe7pLumsHiW-emIdBgVhEgDDYdGaLq1E8QjB0WbIfufnJp-CJa3Ieu9gmDASTlQBeEREeA9gfoZcTpYD8elhJIJxaPJKXchvUVkFhZarcivlKoqVuaFPzsJM7KQCBC8zfS0t_oiBka-uzg3_Hl153nMTDaCAbZULPZGE-p2EazI2eFBCDktdHtDffJNo7i7ZYSkWkqN9ysr2QZRvYG_PYCzcYSo34Gf5WNvHKuz0Ye3kFkckfuirCmzr3knw2azrSOmpTOX_RSlMlse7HgFYwxHPMJnzPS19ymiwKZPgrAMvCmAUZmsxZGDoKeusNEDGSSFhLcTQys20qGBGYasIgKYGjAKGjK7SCxSOCGBQSU496XBkXQEeOB7k9Sh8jdB0pQGAZw9Ntwvrts2DjIUcsQBv-XEGfnHQXoBmDgzwzYEWxeHd0oNbPIlz7CqvNseoKu6uPZl85xynum6aWd6BDDAtwobbqYkuMUfOUhXf_cH13kWSnuJ6QrOxah94JzAnda3tWRDQ3RajOOjk-OXhbOqi8QMJRFdA_C-xMwQalM_rTSTKOqyCcaNSTkVmMlmyOt90tptk7jKUizDmGhGbsSU8WMY5mhdZ3eUd5O6gQitiMHI1EqnlaRNsXnKFoJ5yHV82Wp1dhFONCG_dlpqunVJD5bFgpxtdFDD-KmXQTymAalFjxeVl_xdc5xd4XYCYmk5dhEiQBE0J_S3Z6x0tmFORpWG9lESK_OBRSul9oKZh9Vet-UZ8FSOVtNFwbeokRwWpFuFL1dL3UpJeININ2cgUfDNWQlwItkokiFf_Kdy12y2O_hqJtoTpNttNxTOiclDzKM1KHNOjYJgTgydcid3mmJl3eA6ezyrDAw1RLCHBucIvYRfwbkmpYMvnfAaA2DIiaTNaSxX8BUl92V49UVKWlQSp8ijfmmTRHrBMmxKjvBIgHqC6dSMhVUEOMzCKXAO3giCS3eZzdrNQGhhqTxpYYnFf6uLoKOIiaGY-ByI1YoIVXxX8aCTOOpesFvHjwOKBEoj4Hoxd3iFMUJQazR7P2drnfmS11kgipM7pSUgB7POKwxEF0NQCedM41wVIuoathAqD6N6qalwQ6iOKlZOBUwwMVAMRDJ3aomG37ZeLYhv6fB0-pUUJSN1q4knjtkLFIJSUrih9FZ0XnOll_aeEgOICqQkb4aOMrovjcJEWvgdjUqGPdyIGgkurfqBRHih3dukUcYxt6Y__4KLQ7acqMx0FOFv0ZxFRTCIRGj_GAlFWUi6fpuPKebXUnEn1PRE0iNXwUV_4jESWb0"
		},
		...
	]
}
*/
	constructor(payload) {
		this.input = payload || '';
		try {
			let content = JSON.parse(this.input.trim());
			Object.keys(content).forEach(key => this[key] = content[key]);
		} catch {}

		this.method ||= hm.vless_encryption.methods[0][0];
		this.xormode ||= hm.vless_encryption.xormodes[0][0];
		this.ticket ||= hm.vless_encryption.tickets[0][0];
		this.rtt ||= hm.vless_encryption.rtts[0][0];
		this.paddings ||= [];
		this.keypairs ||= [];
	}

	setKey(key, value) {
		this[key] = value;

		return this
	}

	_toMihomo(payload, side) {
		if (!['server', 'client'].includes(side))
			throw new Error('Unknown side: ' + side); // `Unknown side: '${side}'`

		let required = [
			payload.method,
			payload.xormode,
			side === 'server' ? payload.ticket : side === 'client' ? payload.rtt : null
		].join('.');

		return required +
			(hm.isEmpty(payload.paddings) ? '' : '.' + payload.paddings.join('.')) + // Optional
			(hm.isEmpty(payload.keypairs) ? '' : '.' + payload.keypairs.map(e => e[side]).join('.')); // Required
	}

	toString(format, side) {
		format ||= 'json';

		let payload = hm.removeBlankAttrs({
			method: this.method,
			xormode: this.xormode,
			ticket: this.ticket,
			rtt: this.rtt,
			paddings: this.paddings || [],
			keypairs: this.keypairs || []
		});

		if (format === 'json')
			return JSON.stringify(payload);
		else if (format === 'mihomo')
			return this._toMihomo(payload, side);
		else
			throw new Error(`Unknown format: '${format}'`);
	}
}

function renderListeners(s, uciconfig, isClient) {
	let o;

	s.tab('field_general', _('General fields'));
	s.tab('field_plugin', _('Plugin fields'));
	s.tab('field_vless_encryption', _('Vless Encryption fields'));
	s.tab('field_hysteria2_realm', _('Hysteria2 Realm fields'));
	s.tab('field_tls', _('TLS fields'));
	s.tab('field_transport', _('Transport fields'));
	s.tab('field_multiplex', _('Multiplex fields'));
	s.tab('field_listen', _('Listen fields'));

	/* General fields */
	o = s.taboption('field_general', form.Value, 'label', _('Label'));
	o.load = hm.loadDefaultLabel;
	o.validate = hm.validateUniqueValue;
	o.modalonly = true;

	o = s.taboption('field_general', form.Flag, 'enabled', _('Enable'));
	o.default = o.enabled;
	o.editable = true;

	o = s.taboption('field_general', form.Flag, 'auto_firewall', _('Firewall'),
		_('Auto configure firewall'));
	o.default = o.enabled;
	o.editable = true;

	o = s.taboption('field_general', form.ListValue, 'type', _('Type'));
	o.default = hm.inbound_type[0][0];
	hm.inbound_type.forEach((res) => {
		o.value.apply(o, res);
	})

	o = s.taboption('field_general', form.Value, 'listen', _('Listen address'));
	o.datatype = 'ipaddr';
	o.placeholder = '::';
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'listen_port', _('Listen port') + ' / ' + _('Ports pool'));
	//o.datatype = 'or(port, portrange)'; // ⬇️ migrated to validate
	o.placeholder = '1080,2079-2080,3080';
	o.rmempty = false;
	o.validate = hm.validateCommonPort;

	/* HTTP / SOCKS fields */
	/* hm.validateAuth */
	o = s.taboption('field_general', form.Value, 'username', _('Username'));
	o.validate = hm.validateAuthUsername;
	o.depends({type: /^(http|socks|mixed|mieru|trojan|anytls|hysteria2|trusttunnel)$/});
	o.modalonly = true;

	o = s.taboption('field_general', hm.GenValue, 'password', _('Password'));
	o.password = true;
	o.validate = hm.validateAuthPassword;
	o.rmempty = false;
	o.depends({type: /^(http|socks|mixed|mieru|trojan|anytls|hysteria2|trusttunnel)$/, username: /.+/});
	o.depends({type: /^(tuic)$/, uuid: /.+/});
	o.modalonly = true;

	/* Shadowsocks fields */
	o = s.taboption('field_general', form.ListValue, 'shadowsocks_chipher', _('Chipher'));
	o.default = hm.shadowsocks_cipher_methods[1][0];
	hm.shadowsocks_cipher_methods.forEach((res) => {
		o.value.apply(o, res);
	})
	o.depends('type', 'shadowsocks');
	o.modalonly = true;

	o = s.taboption('field_general', hm.GenValue, 'shadowsocks_password', _('Password'));
	o.password = true;
	o.validate = function(section_id, value) {
		const encmode = this.section.getOption('shadowsocks_chipher').formvalue(section_id);
		return hm.validateShadowsocksPassword.call(this, encmode, section_id, value);
	}
	o.depends({type: 'shadowsocks', shadowsocks_chipher: /.+/});
	o.modalonly = true;

	/* Mieru fields */
	o = s.taboption('field_general', form.ListValue, 'mieru_transport', _('Transport'));
	o.default = 'TCP';
	o.value('TCP');
	o.value('UDP');
	o.depends('type', 'mieru');
	o.modalonly = true;

	o = s.taboption('field_general', form.Flag, 'mieru_user_hint_is_mandatory', _('User-hint is mandatory'),);
	o.default = o.disabled;
	o.depends('type', 'mieru');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'mieru_tcp_idle_timeout', _('TCP idle timeout'),
		_('In seconds.') + ' ' + _('Minimum value is $s.').format('60'));
	o.placeholder = '1800';
	o.validate = hm.validateTimeDuration;
	o.depends('type', 'mieru');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'mieru_traffic_pattern', _('Traffic pattern'),
		_('A base64 string is used to fine-tune network behavior.<br/>Please refer to the <a target="_blank" href="%s" rel="noreferrer noopener">document</a>.')
		.format('https://github.com/enfein/mieru/blob/main/docs/traffic-pattern.md'));
	o.depends('type', 'mieru');
	o.modalonly = true;

	/* Sudoku fields */
	const sudoku_keytypes = [
		['sudoku-keypair', _('sudoku-keypair')],
		['uuid', _('UUID')]
	]
	o = s.taboption('field_general', hm.GenValue, 'sudoku_key', _('Public key'),
		_('The ED25519 master public key or UUID generated by Sudoku.'));
	o.password = true;
	o.hm_options = {
		type: sudoku_keytypes[0][0],
		callback: function(result) {
			if (result.uuid)
				return [
					[this.option, result.uuid],
					['sudoku_client_key', result.uuid]
				]
			else
				return [
					[this.option, result.public_key],
					['sudoku_client_key', result.private_key]
				]
		}
	}
	o.renderWidget = function(section_id, option_index, cfgvalue) {
		let node = form.Value.prototype.renderWidget.apply(this, arguments);
		const cbid = this.cbid(section_id) + '._keytype_select';
		const selected = this.hm_options.type;

		let selectEl = E('select', {
			id: cbid,
			class: 'cbi-input-select',
			style: 'width: 10em',
		});

		sudoku_keytypes.forEach(([k, v]) => {
			selectEl.appendChild(E('option', {
				'value': k,
				'selected': (k === selected) ? '' : null
			}, [ v ]));
		});

		node.appendChild(E('div',  { 'class': 'control-group' }, [
			selectEl,
			E('button', {
				class: 'cbi-button cbi-button-add',
				click: ui.createHandlerFn(this, () => {
					this.hm_options.type = document.getElementById(cbid).value;

					return hm.handleGenKey.call(this, section_id, this.hm_options);
				})
			}, [ _('Generate') ])
		]));

		return node;
	}
	o.rmempty = false;
	o.depends('type', 'sudoku');
	o.modalonly = true;

	o = s.taboption('field_general', hm.CopyValue, 'sudoku_client_key', _('Client private key'));
	o.depends('type', 'sudoku');
	o.modalonly = true;

	o = s.taboption('field_general', form.ListValue, 'sudoku_aead_method', _('Chipher'));
	o.default = hm.sudoku_cipher_methods[0][0];
	hm.sudoku_cipher_methods.forEach((res) => {
		o.value.apply(o, res);
	})
	o.validate = function(section_id, value) {
		const pure_downlink = this.section.getUIElement(section_id, 'sudoku_enable_pure_downlink')?.node.querySelector('input').checked;

		if (value === 'none' && pure_downlink === false)
			return _('Expecting: %s').format(_('Chipher must be enabled if obfuscate downlink is disabled.'));

		return true;
	}
	o.depends('type', 'sudoku');
	o.modalonly = true;

	o = s.taboption('field_general', form.ListValue, 'sudoku_table_type', _('Obfuscate type'));
	o.value('prefer_ascii', _('Obfuscated as %s').format(_('ASCII data stream')));
	o.value('prefer_entropy', _('Obfuscated as %s').format(_('Low-entropy data stream')));
	o.value('up_ascii_down_entropy', _('UP: %s; DOWN: %s').format(_('ASCII data stream'), _('Low-entropy data stream')));
	o.value('up_entropy_down_ascii', _('UP: %s; DOWN: %s').format(_('Low-entropy data stream'), _('ASCII data stream')));
	o.depends('type', 'sudoku');
	o.modalonly = true;

	o = s.taboption('field_general', form.DynamicList, 'sudoku_custom_tables', _('Custom byte layout'),
			_('Only applies to the %s.').format(_('Low-entropy data stream')));
	o.renderWidget = function(section_id, option_index, cfgvalue) {
		let node = form.DynamicList.prototype.renderWidget.apply(this, arguments);

		(node.querySelector('.control-group') || node).appendChild(E('button', {
			class: 'cbi-button cbi-button-positive',
			title: _('Generate'),
			click: ui.createHandlerFn(this, hm.handleGenKey, section_id, this.hm_options || this.option)
		}, [ _('Generate') ]));

		return node;
	}
	o.validate = hm.validateSudokuCustomTable;
	o.depends({sudoku_table_type: /^(prefer_entropy|up_ascii_down_entropy|up_entropy_down_ascii)$/});
	o.modalonly = true;

	o = s.taboption('field_general', form.RangeSliderValue, 'sudoku_padding_min', _('Minimum padding rate'));
	o.datatype = 'and(uinteger, range(0, 100))';
	o.default = 1;
	o.min = 0;
	o.max = 100;
	o.step = 1;
	o.calcunits = '%';
	o.rmempty = false;
	o.depends('type', 'sudoku');
	o.modalonly = true;

	o = s.taboption('field_general', form.RangeSliderValue, 'sudoku_padding_max', _('Maximum padding rate'));
	o.datatype = 'and(uinteger, range(0, 100))';
	o.default = 15;
	o.min = 0;
	o.max = 100;
	o.step = 1;
	o.calcunits = '%';
	o.rmempty = false;
	o.validate = function(section_id, value) {
		const padding_min = this.section.getOption('sudoku_padding_min').formvalue(section_id);

		if (value < padding_min)
			return _('Expecting: %s').format(_('Maximum padding rate must be greater than or equal to the minimum padding rate.'));

		return true;
	}
	o.depends('type', 'sudoku');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'sudoku_handshake_timeout', _('Handshake timeout'),
		_('In seconds.'));
	o.datatype = 'uinteger';
	o.placeholder = 5;
	o.depends('type', 'sudoku');
	o.modalonly = true;

	o = s.taboption('field_general', form.Flag, 'sudoku_enable_pure_downlink', _('Enable obfuscate for downlink'),
		_('false = bandwidth optimized downlink; true = pure Sudoku downlink.'));
	o.default = o.enabled;
	o.depends('type', 'sudoku');
	o.modalonly = true;

	o = s.taboption('field_general', form.Flag, 'sudoku_http_mask', _('HTTP mask'));
	o.default = o.enabled;
	o.depends('type', 'sudoku');
	o.modalonly = true;

	o = s.taboption('field_general', form.ListValue, 'sudoku_http_mask_mode', _('HTTP mask mode'));
	o.default = 'legacy';
	o.value('legacy', _('Legacy'));
	o.value('stream', _('split-stream') + ' - ' + _('CDN support'));
	o.value('poll', _('poll') + ' - ' + _('CDN support'));
	o.value('auto', _('Auto') + ' - ' + _('CDN support'));
	o.value('ws', _('WebSocket') + ' - ' + _('CDN support'));
	o.depends('sudoku_http_mask', '1');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'sudoku_path_root', _('HTTP root path'));
	o.depends('sudoku_http_mask', '1');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'sudoku_fallback', _('Fallback'));
	o.datatype = 'hostport';
	o.placeholder = '127.0.0.1:80';
	o.depends('sudoku_http_mask', '1');
	o.modalonly = true;

	/* Snell fields */
	o = s.taboption('field_general', hm.GenValue, 'snell_psk', _('Pre-shared key'));
	o.password = true;
	o.rmempty = false;
	o.validate = hm.validateAuthPassword;
	o.depends('type', 'snell');
	o.modalonly = true;

	o = s.taboption('field_general', form.ListValue, 'snell_version', _('Version'));
	o.value('1', _('v1'));
	o.value('2', _('v2'));
	o.value('3', _('v3'));
	o.value('4', _('v4'));
	o.value('5', _('v5'));
	o.value('6', _('v6'));
	o.default = '4';
	o.depends('type', 'snell');
	o.modalonly = true;

	o = s.taboption('field_general', form.ListValue, 'snell_mode', _('Traffic mode'));
	o.value('', _('Keep default'));
	o.value('default', _('Default'));
	o.value('unshaped', _('No obfuscation'));
	o.value('unsafe-raw', _('No encryption No obfuscation'));
	o.depends({type: 'snell', snell_version: /^(6)$/});
	o.modalonly = true;

	/* VMess / VLESS fields */
	o = s.taboption('field_general', hm.GenValue, 'vmess_uuid', _('UUID'));
	o.rmempty = false;
	o.validate = hm.validateUUID;
	o.depends({type: /^(vmess|vless)$/});
	o.modalonly = true;

	o = s.taboption('field_general', form.ListValue, 'vless_flow', _('Flow'));
	o.default = hm.vless_flow[0][0];
	hm.vless_flow.forEach((res) => {
		o.value.apply(o, res);
	})
	o.depends('type', 'vless');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'vmess_alterid', _('Alter ID'),
		_('Legacy protocol support (VMess MD5 Authentication) is provided for compatibility purposes only, use of alterId > 1 is not recommended.'));
	o.datatype = 'uinteger';
	o.placeholder = '0';
	o.depends('type', 'vmess');
	o.modalonly = true;

	/* Trojan fields */
	o = s.taboption('field_general', form.Flag, 'trojan_ss_enabled', _('Shadowsocks encrypt'));
	o.default = o.disabled;
	o.depends('type', 'trojan');
	o.modalonly = true;

	o = s.taboption('field_general', form.ListValue, 'trojan_ss_chipher', _('Shadowsocks chipher'));
	o.default = hm.trojan_cipher_methods[0][0];
	hm.trojan_cipher_methods.forEach((res) => {
		o.value.apply(o, res);
	})
	o.depends({type: 'trojan', trojan_ss_enabled: '1'});
	o.modalonly = true;

	o = s.taboption('field_general', hm.GenValue, 'trojan_ss_password', _('Shadowsocks password'));
	o.password = true;
	o.validate = function(section_id, value) {
		const encmode = this.section.getOption('trojan_ss_chipher').formvalue(section_id);
		return hm.validateShadowsocksPassword.call(this, encmode, section_id, value);
	}
	o.depends({type: 'trojan', trojan_ss_enabled: '1'});
	o.modalonly = true;

	/* AnyTLS fields */
	o = s.taboption('field_general', form.TextValue, 'anytls_padding_scheme', _('Padding scheme'));
	o.depends('type', 'anytls');
	o.modalonly = true;

	/* Tuic fields */
	o = s.taboption('field_general', hm.GenValue, 'uuid', _('UUID'));
	o.rmempty = false;
	o.validate = hm.validateUUID;
	o.depends('type', 'tuic');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'tuic_max_udp_relay_packet_size', _('Max UDP relay packet size'));
	o.datatype = 'uinteger';
	o.default = '1500';
	o.depends('type', 'tuic');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'tuic_authentication_timeout', _('Auth timeout'),
		_('In seconds.'));
	o.default = '1000';
	o.validate = hm.validateTimeDuration;
	o.depends('type', 'tuic');
	o.modalonly = true;

	/* Brutal fields */
	o = s.taboption('field_general', form.Value, 'brutal_up_mbps', _('Max upload speed'),
		_('In Mbps.'));
	o.datatype = 'uinteger';
	o.depends({type: /^(hysteria2|shadowquic)$/});
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'brutal_down_mbps', _('Max download speed'),
		_('In Mbps.'));
	o.datatype = 'uinteger';
	o.depends({type: /^(hysteria2|shadowquic)$/});
	o.modalonly = true;

	o = s.taboption('field_general', form.Flag, 'brutal_ignore_client_bandwidth', _('Ignore client bandwidth'),
		_('Tell the client to use the BBR flow control algorithm instead of Hysteria CC.'));
	o.default = o.disabled;
	o.depends({type: /^(hysteria2|shadowquic)$/, brutal_up_mbps: '', brutal_down_mbps: ''});
	o.modalonly = true;

	/* Hysteria2 fields */
	o = s.taboption('field_general', form.ListValue, 'hysteria_obfs_type', _('Obfuscate type'));
	o.value('', _('Disable'));
	o.value('salamander', _('Salamander'));
	o.value('gecko', _('Gecko'));
	o.depends('type', 'hysteria2');
	o.modalonly = true;

	o = s.taboption('field_general', hm.GenValue, 'hysteria_obfs_password', _('Obfuscate password'),
		_('Enabling obfuscation will make the server incompatible with standard QUIC connections, losing the ability to masquerade with HTTP/3.'));
	o.password = true;
	o.rmempty = false;
	o.depends('type', 'hysteria');
	o.depends({type: 'hysteria2', hysteria_obfs_type: /.+/});
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'hysteria_obfs_min_packet_size', _('Obfuscate minimum packet size'));
	o.placeholder = '512'
	o.depends('hysteria_obfs_type', 'gecko');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'hysteria_obfs_max_packet_size', _('Obfuscate maximum packet size'));
	o.placeholder = '1200'
	o.depends('hysteria_obfs_type', 'gecko');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'hysteria_masquerade', _('Masquerade'),
		_('HTTP3 server behavior when authentication fails.<br/>A 404 page will be returned if empty.'));
	o.placeholder = 'file:///var/www or http://127.0.0.1:8080'
	o.depends('type', 'hysteria2');
	o.modalonly = true;

	/* Hysteria2 Realmserver fields */
	o = s.taboption('field_general', form.Value, 'hysteria2_realmserver_token', _('Pre-shared key'));
	o.placeholder = 'public';
	o.rmempty = false;
	o.depends('type', 'hysteria2-realm');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'hysteria2_realmserver_max_realms', _('Max realms'));
	o.datatype = 'uinteger';
	o.placeholder = '65536';
	o.depends('type', 'hysteria2-realm');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'hysteria2_realmserver_max_realms_per_ip', _('Max realms per client IP'));
	o.datatype = 'uinteger';
	o.placeholder = '4';
	o.depends('type', 'hysteria2-realm');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'hysteria2_realmserver_trusted_proxy_header', _('Trusted proxy header'),
		_('Header to read real client IP from (e.g. X-Forwarded-For)'));
	o.depends('type', 'hysteria2-realm');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'hysteria2_realmserver_realm_name_pattern', _('Realm name pattern'));
	o.default = '^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$';
	o.rmempty = false;
	o.depends('type', 'hysteria2-realm');
	o.modalonly = true;

	/* ShadowQUIC fields */
	o = s.taboption('field_general', form.DynamicList, 'shadowquic_quic_versions', _('QUIC versions'),
		_('Default version, Support %s.').format('v1/v2'));
	o.placeholder = 'v1';
	o.depends('type', 'shadowquic');
	o.modalonly = true;

	o = s.taboption('field_general', form.Flag, 'shadowquic_zero_rtt', _('QUIC based 0-RTT'));
	o.default = o.disabled;
	o.depends('type', 'shadowquic');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'shadowquic_cwnd', _('Initial congestion window size'));
	o.datatype = 'uinteger';
	o.placeholder = '10';
	o.depends('type', 'shadowquic');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'shadowquic_max_datagram_frame_size', _('Max datagram frame size'));
	o.datatype = 'uinteger';
	o.placeholder = '1400';
	o.depends('type', 'shadowquic');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'shadowquic_recv_window_conn', _('Stream-level receive window size'));
	o.datatype = 'uinteger';
	o.placeholder = '0';
	o.depends('type', 'shadowquic');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'shadowquic_recv_window', _('Connection-level receive window size'));
	o.datatype = 'uinteger';
	o.placeholder = '0';
	o.depends('type', 'shadowquic');
	o.modalonly = true;

	o = s.taboption('field_general', form.Flag, 'shadowquic_mtu_discovery', _('Path MTU Discovery'));
	o.default = o.enabled;
	o.depends('type', 'shadowquic');
	o.modalonly = true;

	/* TrustTunnel fields */

	/* Tunnel fields */
	o = s.taboption('field_general', form.Value, 'tunnel_target', _('Target address'));
	o.datatype = 'hostport';
	o.placeholder = 'target.com:53';
	o.depends('type', 'tunnel');
	o.modalonly = true;

	/* Extra fields */
	if (isClient) {
		o = s.taboption('field_general', form.Value, 'routing_mark', _('Routing mark (Fwmark)'));
		o.datatype = 'uinteger';
		o.modalonly = false;
		o.editable = true;

		o = s.taboption('field_general', hm.ListValue, 'rule', _('Sub rule'),
			_('Name of the Sub rule used for inbound matching.'));
		o.value.apply(o, ['', _('none')]);
		o.load = function(section_id) {
			return hm.loadChoices.call(this, [
				['', _('none')],
				...hm.loadChoicesGetMap(this.config, 'subrule-group')
			], section_id);
		}
		o.modalonly = false;
		o.editable = true;

		o = s.taboption('field_general', hm.ListValue, 'proxy', _('Proxy group'),
			_('Name of the Proxy group as outbound.'));
		o.default = hm.preset_outbound.direct[0][0];
		hm.preset_outbound.direct.forEach((res) => {
			o.value.apply(o, res);
		})
		o.load = function(section_id) {
			return hm.loadChoices.call(this, [
				...hm.preset_outbound.direct,
				...hm.loadChoicesGetMap(this.config, 'proxy_group')
			], section_id);
		}
		o.modalonly = false;
		o.editable = true;
	}

	o = s.taboption('field_general', form.ListValue, 'congestion_controller', _('Congestion controller'));
	o.default = hm.congestion_controller[0][0];
	hm.congestion_controller.forEach((res) => {
		o.value.apply(o, res);
	})
	o.depends({type: /^(tuic|shadowquic|trusttunnel)$/});
	o.modalonly = true;

	o = s.taboption('field_general', form.ListValue, 'bbr_profile', _('BBR profile'));
	o.default = hm.bbr_profiles[0][0];
	hm.bbr_profiles.forEach((res) => {
		o.value.apply(o, res);
	})
	o.depends('congestion_controller', 'bbr');
	o.depends('type', 'hysteria2');
	o.modalonly = true;

	o = s.taboption('field_general', form.Value, 'max_idle_time', _('Idle timeout'),
		_('In seconds.'));
	o.placeholder = '15000';
	o.validate = hm.validateTimeDuration;
	o.depends({type: /^(tuic|shadowquic)$/});
	o.modalonly = true;

	o = s.taboption('field_general', form.MultiValue, 'network', _('Network type'));
	o.value('tcp', _('TCP'));
	o.value('udp', _('UDP'));
	o.rmempty = false;
	o.depends({type: /^(trusttunnel|tunnel)$/});
	o.modalonly = true;

	o = s.taboption('field_general', form.Flag, 'udp', _('UDP'));
	o.default = o.enabled;
	o.depends({type: /^(socks|mixed|shadowsocks|snell)$/});
	o.modalonly = true;

	/* Plugin fields */
	o = s.taboption('field_general', form.Flag, 'plugin', _('Plugin'));
	o.default = o.disabled;
	o.depends({type: /^(shadowsocks|snell)$/});
	o.depends({type: /^(vmess|vless|trojan|anytls)$/});
	o.modalonly = true;

	o = s.taboption('field_plugin', form.ListValue, 'plugin_type', _('Plugin type'));
	o.value('obfs', _('obfs-simple'));
	o.value('shadow-tls', _('ShadowTLS'));
	o.value('restls', _('Restls'));
	o.value('jls', _('JLS'));
	//o.value('kcp-tun', _('kcp-tun'));
	o.validate = function(section_id, value) {
		const type = this.section.getOption('type').formvalue(section_id);
		const snell_version = this.section.getOption('snell_version').formvalue(section_id);

		if (value) {
			if (type === 'snell' && !['shadow-tls', 'restls', 'jls'].includes(value)) {
				let obfs_simple_supported = true;
				if (Number(snell_version) < 6) {
					if (value === 'obfs')
						return true;
				} else
					obfs_simple_supported = false;

				return _('Expecting: Only support %s.').format(
					(obfs_simple_supported ? _('obfs-simple') + ' / ' : '') +
					_('ShadowTLS') +
					' / ' + _('Restls') +
					' / ' + _('JLS'));
			}
			if (['vmess', 'vless', 'trojan', 'anytls'].includes(type) && !['shadow-tls', 'restls', 'jls'].includes(value)) {
				return _('Expecting: Only support %s.').format(_('ShadowTLS') +
					' / ' + _('Restls') +
					' / ' + _('JLS'));
			}
		}

		return true;
	}
	o.depends('plugin', '1');
	o.modalonly = true;

	o = s.taboption('field_plugin', form.ListValue, 'plugin_opts_obfsmode', _('Obfs Mode'));
	o.value('http', _('HTTP'));
	o.value('tls', _('TLS'));
	o.depends('plugin_type', 'obfs');
	o.modalonly = true;

	o = s.taboption('field_plugin', form.Value, 'plugin_opts_handshake_dest', _('Handshake target that supports TLS 1.3'));
	o.datatype = 'hostport';
	o.placeholder = 'cloud.tencent.com:443';
	o.rmempty = false;
	o.depends({plugin_type: /^(shadow-tls|restls|jls)$/});
	o.depends({type: 'shadowquic'});
	o.modalonly = true;

	o = s.taboption('field_plugin', form.Value, 'plugin_opts_host', _('Host that supports TLS 1.3'));
	o.datatype = 'hostname';
	o.placeholder = 'cloud.tencent.com';
	o.depends({type: 'snell', plugin_type: 'obfs'});
	o.depends({plugin_type: 'jls'});
	o.depends({type: 'shadowquic'});
	o.modalonly = true;

	o = s.taboption('field_plugin', form.Value, 'plugin_opts_thetlsusername', _('Username'));
	o.validate = hm.validateAuthUsername;
	o.rmempty = false;
	o.depends({plugin_type: 'jls'});
	o.depends({type: 'shadowquic'});
	o.modalonly = true;

	o = s.taboption('field_plugin', hm.GenValue, 'plugin_opts_thetlspassword', _('Password'));
	o.password = true;
	o.rmempty = false;
	o.depends({plugin_type: /^(shadow-tls|restls|jls)$/});
	o.depends({type: 'shadowquic'});
	o.modalonly = true;

	o = s.taboption('field_plugin', form.ListValue, 'plugin_opts_shadowtls_version', _('Version'));
	o.value('1', _('v1'));
	o.value('2', _('v2'));
	o.value('3', _('v3'));
	o.default = '3';
	o.depends({plugin_type: 'shadow-tls'});
	o.modalonly = true;

	o = s.taboption('field_plugin', form.Value, 'plugin_opts_restls_script', _('Restls script'));
	o.default = '300?100<1,400~100,350~100,600~100,300~200,300~100';
	o.rmempty = false;
	o.depends({plugin_type: 'restls'});
	o.modalonly = true;

	if (isClient) {
		o = s.taboption('field_plugin', form.ListValue, 'plugin_opts_dest_proxy', _('Handshake target proxy'),
			_('The proxy used to connect to the handshake target.'));
		o.default = hm.preset_outbound.direct[0][0];
		hm.preset_outbound.direct.forEach((res) => {
			o.value.apply(o, res);
		})
		o.load = function(section_id) {
			return hm.loadChoices.call(this, [
				...hm.preset_outbound.direct,
				...hm.loadChoicesGetMap(this.config, 'proxy_group')
			], section_id);
		}
		o.depends('tls_reality', '1');
		o.depends({plugin_type: /^(shadow-tls|restls|jls)$/});
		o.depends({type: 'shadowquic'});
		o.modalonly = true;
	}

	o = s.taboption('field_plugin', form.Value, 'plugin_opts_rate_limit', _('Forwarding rate limit'),
		_('In bps. 0 means no speed limit.'));
	o.datatype = 'uinteger';
	o.depends({plugin_type: /^(restls|jls)$/});
	o.depends({type: 'shadowquic'});
	o.modalonly = true;

	/* Vless Encryption fields */
	o = s.taboption('field_general', form.Flag, 'vless_decryption', _('decryption'));
	o.default = o.disabled;
	o.depends('type', 'vless');
	o.modalonly = true;

	o = s.taboption('field_vless_encryption', form.Value, 'vless_encryption_hmpayload', _('Payload'));
	o.readonly = true;
	o.depends('vless_decryption', '1');
	o.modalonly = true;

	o = s.taboption('field_vless_encryption', CBIDummyCopyValue, '_vless_encryption_decryption', _('decryption'));
	o.depends('vless_decryption', '1');
	o.modalonly = true;

	o = s.taboption('field_vless_encryption', CBIDummyCopyValue, '_vless_encryption_encryption', _('encryption'));
	o.depends('vless_decryption', '1');
	o.modalonly = true;

	// common part
	const initVlessEncryptionOption = function(o, key,
		load_callback = (k, inst) => inst[k],
		onchange_callback = (k, v, inst) => inst.setKey(k, v)
	) {
		o.load = function(section_id) {
			return load_callback(key, new VlessEncryption(uci.get(uciconfig, section_id, 'vless_encryption_hmpayload')));
		}
		o.onchange = function(ev, section_id, value) {
			let UIEl = this.section.getUIElement(section_id, 'vless_encryption_hmpayload');
			let newpayload = onchange_callback(key, value, new VlessEncryption(UIEl.getValue()));

			UIEl.setValue(newpayload.toString());

			[
				['server', '_vless_encryption_decryption'],
				['client', '_vless_encryption_encryption']
			].forEach(([side, option]) => {
				UIEl = this.section.getUIElement(section_id, option);
				UIEl.setValue(newpayload.toString('mihomo', side));
			});
		}
		o.write = function() {};
		o.depends('vless_decryption', '1');
		o.modalonly = true;
	}

	o = s.taboption('field_vless_encryption', form.ListValue, 'vless_encryption_method', _('Encryption method'));
	o.default = hm.vless_encryption.methods[0][0];
	hm.vless_encryption.methods.forEach((res) => {
		o.value.apply(o, res);
	})
	initVlessEncryptionOption(o, 'method');

	o = s.taboption('field_vless_encryption', form.RichListValue, 'vless_encryption_xormode', _('XOR mode'));
	o.default = hm.vless_encryption.xormodes[0][0];
	hm.vless_encryption.xormodes.forEach((res) => {
		o.value.apply(o, res);
	})
	initVlessEncryptionOption(o, 'xormode');

	o = s.taboption('field_vless_encryption', hm.RichValue, 'vless_encryption_ticket', _('Server') +' '+ _('RTT'));
	o.default = hm.vless_encryption.tickets[0][0];
	hm.vless_encryption.tickets.forEach((res) => {
		o.value.apply(o, res);
	})
	initVlessEncryptionOption(o, 'ticket');
	o.validate = function(section_id, value) {
		if (!value)
			return true;

		if (!value.match(/^(\d+-)?\d+s$/))
			return _('Expecting: %s').format('^(\\d+-)?\\d+s$');

		return true;
	}
	o.rmempty = false;

	o = s.taboption('field_vless_encryption', form.ListValue, 'vless_encryption_rtt', _('Client') +' '+ _('RTT'));
	o.default = hm.vless_encryption.rtts[0][0];
	hm.vless_encryption.rtts.forEach((res) => {
		o.value.apply(o, res);
	})
	initVlessEncryptionOption(o, 'rtt');
	o.rmempty = false;

	o = s.taboption('field_vless_encryption', hm.less_25_12 ? hm.DynamicList : form.DynamicList, 'vless_encryption_paddings', _('Paddings'), // @less_25_12
		_('The server and client can set different padding parameters.') + '</br>' +
		_('In the order of one <code>Padding-Length</code> and one <code>Padding-Interval</code>, infinite concatenation.') + '</br>' +
		_('The first padding must have a probability of 100% and at least 35 bytes.'));
	hm.vless_encryption.paddings.forEach((res) => {
		o.value.apply(o, res);
	})
	initVlessEncryptionOption(o, 'paddings');
	o.validate = function(section_id, value) {
		if (!value)
			return true;

		if (!value.match(/^\d+(-\d+){2}$/))
			return _('Expecting: %s').format('^\\d+(-\\d+){2}$');

		return true;
	}
	o.allowduplicates = true;

	o = s.taboption('field_vless_encryption', hm.GenText, 'vless_encryption_keypairs', _('Keypairs'));
	o.placeholder = '[\n  {\n    "type": "vless-x25519",\n    "server": "cP5Oy9MOpTaBKKE17Pfd56mbb1CIfp5EMpyBYqr2EG8",\n    "client": 	"khEcQMT8j41xWmGYKpZtQ4vd8_9VWyFVmmCDIhRJ-Uk"\n  },\n  {\n    "type": "vless-mlkem768",\n    "server": 	"UHPx3nf-FVxF95byAw0YG025aQNw9HxKej-MiG5AhTcdW_WFpHlTVYQU5NHmXP6tmljSnB2iPmSQ29fisGxEog",\n    "client": 	"h4sdZgCc5-ZefvQ8mZmReOWQdxYb0mwngMdl7pKhYEZZpGWHUPKAmxug87Bgj3GqSHs195QeVpxfrMLNB5J..."\n  },\n  ...\n]';
	o.rows = 10;
	o.hm_options = {
		type: hm.vless_encryption.keypairs.types[0][0],
		params: '',
		callback: function(result) {
			const section_id = this.section.section;
			const key_type = this.hm_options.type;

			let keypair = {"type": key_type, "server": "", "client": ""};
			switch (key_type) {
				case 'vless-x25519':
					keypair.server = result.private_key;
					keypair.client = result.password;
					break;
				case 'vless-mlkem768':
					keypair.server = result.seed;
					keypair.client = result.client;
					break;
				default:
					break;
			}

			let keypairs = [];
			try {
				keypairs = JSON.parse(this.formvalue(section_id).trim());
			} catch {}
			if (!Array.isArray(keypairs))
				keypairs = [];

			keypairs.push(keypair);

			return [
				[this.option, JSON.stringify(keypairs, null, 2)]
			]
		}
	}
	o.renderWidget = function(section_id, option_index, cfgvalue) {
		let node = hm.TextValue.prototype.renderWidget.apply(this, arguments);
		const cbid = this.cbid(section_id) + '._keytype_select';
		const selected = this.hm_options.type;

		let selectEl = E('select', {
			id: cbid,
			class: 'cbi-input-select',
			style: 'width: 10em',
		});

		hm.vless_encryption.keypairs.types.forEach(([k, v]) => {
			selectEl.appendChild(E('option', {
				'value': k,
				'selected': (k === selected) ? '' : null
			}, [ v ]));
		});

		node.appendChild(E('div',  { 'class': 'control-group' }, [
			selectEl,
			E('button', {
				class: 'cbi-button cbi-button-add',
				click: ui.createHandlerFn(this, () => {
					this.hm_options.type = document.getElementById(cbid).value;

					return hm.handleGenKey.call(this, section_id, this.hm_options);
				})
			}, [ _('Generate') ])
		]));

		return node;
	}
	initVlessEncryptionOption(o, 'keypairs',
		(k, inst) => JSON.stringify(inst[k], null, 2)
	);
	const keypairs_onchange = o.onchange;
	o.onchange = function() {};
	o.validate = function(section_id, value) {
		let result = hm.validateJson.call(this, section_id, value);

		if (result === true) {
			let keypairs = JSON.parse(value.trim());

			if (Array.isArray(keypairs) && keypairs.length >= 1) {
				keypairs_onchange.call(this, null, section_id, keypairs);
			} else
				return _('Expecting: %s').format(_('least one keypair required'));

			return true;
		} else
			return result;
	}
	o.rmempty = false;

	// @xhttp-config其他的配置

	/* Hysteria2 Realm fields */
	hm.renderHy2Realm(s, uciconfig);

	if (isClient) {
		o = s.taboption('field_hysteria2_realm', form.ListValue, 'hysteria2_realm_proxy', _('Proxy group'),
			_('The proxy used to connect to the rendezvous server.'));
		o.default = hm.preset_outbound.direct[0][0];
		hm.preset_outbound.direct.forEach((res) => {
			o.value.apply(o, res);
		})
		o.load = function(section_id) {
			return hm.loadChoices.call(this, [
				...hm.preset_outbound.direct,
				...hm.loadChoicesGetMap(this.config, 'proxy_group')
			], section_id);
		}
		o.depends('hysteria2_realm', '1');
		o.modalonly = true;
	}

	/* TLS fields */
	o = s.taboption('field_general', form.Flag, 'tls', _('TLS'));
	o.default = o.disabled;
	o.validate = function(section_id, value) {
		const type = this.section.getOption('type').formvalue(section_id);
		let tls = this.section.getUIElement(section_id, 'tls').node.querySelector('input');
		let allow_insecure = this.section.getUIElement(section_id, 'allow_insecure').node.querySelector('input');
		let tls_reality = this.section.getUIElement(section_id, 'tls_reality').node.querySelector('input');

		// Force enabled
		if (['trojan', 'anytls', 'tuic', 'hysteria2', 'shadowquic', 'trusttunnel'].includes(type)) {
			tls.checked = true;
			tls.disabled = true;
		} else {
			tls.removeAttribute('disabled');
		}

		// Force disabled
		if (!['vless', 'trojan', 'anytls'].includes(type)) {
			allow_insecure.checked = false;
		} else if (allow_insecure.checked) {
			tls.checked = false;
			tls.disabled = true;
		}
		if (!['vmess', 'vless', 'trojan'].includes(type)) {
			tls_reality.checked = false;
			tls_reality.disabled = true;
		} else {
			tls_reality.removeAttribute('disabled');
		}

		return true;
	}
	o.depends({type: /^(http|socks|mixed|vmess|vless|trojan|anytls|tuic|hysteria2|hysteria2-realm|shadowquic|trusttunnel)$/});
	o.modalonly = true;

	o = s.taboption('field_general', form.Flag, 'allow_insecure', _('Allow insecure connections'),
		_('Only applicable when %s are used as a frontend.').format('nginx/caddy'));
	o.default = o.disabled;
	o.depends({type: /^(vless|trojan|anytls)$/});
	o.modalonly = true;

	o = s.taboption('field_tls', form.DynamicList, 'tls_alpn', _('TLS ALPN'),
		_('List of supported application level protocols, in order of preference.'));
	o.validate = function(section_id, value) {
		const type = this.section.getOption('type').formvalue(section_id);
		//const plugin_type = this.section.getOption('plugin_type').formvalue(section_id);
		let tls_alpn = this.section.getUIElement(section_id, 'tls_alpn');

		// Default alpn
		if (!`${tls_alpn.getValue()}`) {
			let def_alpn;

			switch (type) {
				case 'shadowsocks':
				case 'vmess':
				case 'vless':
				case 'trojan':
				case 'anytls':
					def_alpn = ['h2', 'http/1.1']; // when plugin_type in ['jls']
					break;
				case 'tuic':
				case 'hysteria2':
				case 'shadowquic':
					def_alpn = ['h3'];
					break;
				case 'hysteria2-realm':
					def_alpn = ['h2', 'http/1.1'];
					break;
				default:
					def_alpn = [];
			}

			tls_alpn.setValue(def_alpn);
		}

		// Force disabled
		if (['trusttunnel'].includes(type)) {
			tls_alpn.node.querySelector('input').disabled = true;
			tls_alpn.setValue('');
		} else {
			tls_alpn.node.querySelector('input').removeAttribute('disabled');
		}

		return true;
	}
	o.depends('tls', '1');
	o.depends({plugin_type: 'jls'});
	o.modalonly = true;

	o = s.taboption('field_tls', form.Value, 'tls_cert_path', _('Certificate path'),
		_('The %s public key, in PEM format.').format(_('Server')));
	o.value('/etc/fchomo/certs/server_publickey.pem');
	o.validate = function(section_id, value) {
		const plugin_type = this.section.getOption('plugin_type').formvalue(section_id);
		const tls_reality = this.section.getOption('tls_reality').formvalue(section_id);

		if (['shadow-tls', 'restls', 'jls'].includes(plugin_type) || tls_reality == 1) {
			if (value)
				return _('Expecting: Keep empty when %s is enabled.').format(_('ShadowTLS') +
					' / ' + _('Restls') +
					' / ' + _('JLS') +
					' / ' + _('REALITY'));
		} else if (!value) {
			return _('Expecting: Cannot be empty.');
		}

		return true;
	}
	o.depends({tls: '1', type: /^(http|socks|mixed|vmess|vless|trojan|anytls|tuic|hysteria2|hysteria2-realm|trusttunnel)$/});
	o.modalonly = true;

	o = s.taboption('field_tls', form.Button, '_upload_cert', _('Upload certificate'),
		_('<strong>Save your configuration before uploading files!</strong>'));
	o.inputstyle = 'action';
	o.inputtitle = _('Upload...');
	o.depends({tls: '1', tls_cert_path: '/etc/fchomo/certs/server_publickey.pem'});
	o.onclick = L.bind(hm.uploadCertificate, o, _('certificate'), 'server_publickey');
	o.modalonly = true;

	o = s.taboption('field_tls', form.Value, 'tls_key_path', _('Key path'),
		_('The %s private key, in PEM format.').format(_('Server')));
	o.value('/etc/fchomo/certs/server_privatekey.pem');
	o.rmempty = false;
	o.depends({tls: '1', tls_cert_path: /.+/});
	o.modalonly = true;

	o = s.taboption('field_tls', form.Button, '_upload_key', _('Upload key'),
		_('<strong>Save your configuration before uploading files!</strong>'));
	o.inputstyle = 'action';
	o.inputtitle = _('Upload...');
	o.depends({tls: '1', tls_key_path: '/etc/fchomo/certs/server_privatekey.pem'});
	o.onclick = L.bind(hm.uploadCertificate, o, _('private key'), 'server_privatekey');
	o.modalonly = true;

	o = s.taboption('field_tls', form.ListValue, 'tls_client_auth_type', _('Client Auth type') + _(' (mTLS)'));
	o.default = hm.tls_client_auth_types[0][0];
	hm.tls_client_auth_types.forEach((res) => {
		o.value.apply(o, res);
	})
	o.depends({tls: '1', type: /^(http|socks|mixed|vmess|vless|trojan|anytls|tuic|hysteria2|hysteria2-realm|trusttunnel)$/});
	o.modalonly = true;

	o = s.taboption('field_tls', form.Value, 'tls_client_auth_cert_path', _('Client Auth Certificate path') + _(' (mTLS)'),
		_('The %s public key, in PEM format.').format(_('Client')));
	o.value('/etc/fchomo/certs/client_publickey.pem');
	o.validate = function(/* ... */) {
		return hm.validateMTLSClientAuth.call(this, 'tls_client_auth_type', ...arguments);
	}
	o.depends({tls: '1', type: /^(http|socks|mixed|vmess|vless|trojan|anytls|tuic|hysteria2|hysteria2-realm|trusttunnel)$/});
	o.modalonly = true;

	o = s.taboption('field_tls', form.Button, '_upload_client_auth_cert', _('Upload certificate') + _(' (mTLS)'),
		_('<strong>Save your configuration before uploading files!</strong>'));
	o.inputstyle = 'action';
	o.inputtitle = _('Upload...');
	o.depends({tls: '1', tls_client_auth_cert_path: '/etc/fchomo/certs/client_publickey.pem'});
	o.onclick = L.bind(hm.uploadCertificate, o, _('certificate'), 'client_publickey');
	o.modalonly = true;

	o = s.taboption('field_tls', hm.GenText, 'tls_ech_key', _('ECH key'));
	o.placeholder = '-----BEGIN ECH KEYS-----\nACATwY30o/RKgD6hgeQxwrSiApLaCgU+HKh7B6SUrAHaDwBD/g0APwAAIAAgHjzK\nmadSJjYQIf9o1N5GXjkW4DEEeb17qMxHdwMdNnwADAABAAEAAQACAAEAAwAIdGVz\ndC5jb20AAA==\n-----END ECH KEYS-----';
	o.hm_placeholder = 'outer-sni.any.domain';
	o.cols = 30;
	o.rows = 2;
	o.hm_options = {
		type: 'ech-keypair',
		params: '',
		callback: function(result) {
			return [
				[this.option, result.ech_key],
				['tls_ech_config', result.ech_cfg]
			]
		}
	}
	o.renderWidget = function(section_id, option_index, cfgvalue) {
		let node = hm.TextValue.prototype.renderWidget.apply(this, arguments);
		const cbid = this.cbid(section_id) + '._outer_sni';

		node.appendChild(E('div',  { 'class': 'control-group' }, [
			E('input', {
				id: cbid,
				class: 'cbi-input-text',
				style: 'width: 10em',
				placeholder: this.hm_placeholder
			}),
			E('button', {
				class: 'cbi-button cbi-button-add',
				click: ui.createHandlerFn(this, () => {
					this.hm_options.params = document.getElementById(cbid).value;

					return hm.handleGenKey.call(this, section_id, this.hm_options);
				})
			}, [ _('Generate') ])
		]));

		return node;
	}
	o.depends({tls: '1', type: /^(http|socks|mixed|vmess|vless|trojan|anytls|tuic|hysteria2|hysteria2-realm|trusttunnel)$/});
	o.modalonly = true;

	o = s.taboption('field_tls', hm.CopyValue, 'tls_ech_config', _('ECH config'),
		_('This ECH parameter needs to be added to the HTTPS record of the domain.'));
	o.placeholder = 'AEn+DQBFKwAgACABWIHUGj4u+PIggYXcR5JF0gYk3dCRioBW8uJq9H4mKAAIAAEAAQABAANAEnB1YmxpYy50bHMtZWNoLmRldgAA';
	o.depends({tls: '1', type: /^(http|socks|mixed|vmess|vless|trojan|anytls|tuic|hysteria2|hysteria2-realm|trusttunnel)$/});
	o.modalonly = true;

	// uTLS fields
	o = s.taboption('field_tls', form.Flag, 'tls_reality', _('REALITY'));
	o.default = o.disabled;
	o.validate = function(section_id, value) {
		const plugin_type = this.section.getOption('plugin_type').formvalue(section_id);
		value = this.formvalue(section_id);

		if (value == 1 && ['shadow-tls', 'restls', 'jls'].includes(plugin_type))
			return _('Expecting: Cannot be enabled when %s is enabled.').format(_('ShadowTLS') +
				' / ' + _('Restls') +
				' / ' + _('JLS'));

		return true;
	}
	o.depends('tls', '1');
	o.modalonly = true;

	o = s.taboption('field_tls', form.Value, 'tls_reality_dest', _('REALITY handshake server'));
	o.datatype = 'hostport';
	o.placeholder = 'cloud.tencent.com:443';
	o.rmempty = false;
	o.depends('tls_reality', '1');
	o.modalonly = true;

	o = s.taboption('field_tls', hm.GenValue, 'tls_reality_private_key', _('REALITY private key'));
	o.hm_options = {
		type: 'reality-keypair',
		callback: function(result) {
			return [
				[this.option, result.private_key],
				['tls_reality_public_key', result.public_key]
			]
		}
	}
	o.password = true;
	o.rmempty = false;
	o.depends('tls_reality', '1');
	o.modalonly = true;

	o = s.taboption('field_tls', hm.CopyValue, 'tls_reality_public_key', _('REALITY public key'));
	o.depends('tls_reality', '1');
	o.modalonly = true;

	o = s.taboption('field_tls', form.DynamicList, 'tls_reality_short_id', _('REALITY short ID'));
	//o.value('', '""');
	o.rmempty = false;
	o.depends('tls_reality', '1');
	o.modalonly = true;

	o = s.taboption('field_tls', form.DynamicList, 'tls_reality_server_names', _('REALITY certificate issued to'));
	o.datatype = 'list(hostname)';
	o.placeholder = 'cloud.tencent.com';
	o.rmempty = false;
	o.depends('tls_reality', '1');
	o.modalonly = true;

	o = s.taboption('field_tls', form.DynamicList, 'tls_reality_max_time_difference', _('REALITY max time difference'),
		_('In millisecond.'));
	o.datatype = 'uinteger';
	o.depends('tls_reality', '1');
	o.modalonly = true;

	// @VMess-TLSmirror fields

	/* Transport fields */
	o = s.taboption('field_general', form.Flag, 'transport_enabled', _('Transport'));
	o.default = o.disabled;
	o.depends({type: /^(vmess|vless|trojan)$/});
	o.modalonly = true;

	o = s.taboption('field_transport', form.ListValue, 'transport_type', _('Transport type'));
	o.value('grpc', _('gRPC'));
	o.value('ws', _('WebSocket'));
	o.value('xhttp', _('XHTTP'));
	//o.value('mkcp', _('mKCP')); // VMess only
	//o.value('mekya', _('Mekya')); // VMess only
	o.validate = function(section_id, value) {
		const type = this.section.getOption('type').formvalue(section_id);

		switch (type) {
			case 'vless':
				if (!['grpc', 'ws', 'xhttp'].includes(value))
					return _('Expecting: Only support %s.').format(_('gRPC') +
						' / ' + _('WebSocket') +
						' / ' + _('XHTTP'));
				break;
			case 'vmess':
			case 'trojan':
				if (!['grpc', 'ws'].includes(value))
					return _('Expecting: Only support %s.').format(_('gRPC') +
						' / ' + _('WebSocket'));
				break;
			default:
				break;
		}

		return true;
	}
	o.depends('transport_enabled', '1');
	o.modalonly = true;

	o = s.taboption('field_transport', form.Value, 'transport_host', _('Server hostname'));
	o.datatype = 'hostname';
	o.placeholder = 'example.com';
	o.depends({transport_enabled: '1', transport_type: 'xhttp'});
	o.modalonly = true;

	o = s.taboption('field_transport', form.Value, 'transport_path', _('Request path'));
	o.placeholder = '/';
	o.default = '/';
	o.rmempty = false;
	o.depends({transport_enabled: '1', transport_type: /^(ws|xhttp)$/});
	o.modalonly = true;

	o = s.taboption('field_transport', form.Value, 'transport_grpc_servicename', _('gRPC service name'));
	o.placeholder = 'GunService';
	o.rmempty = false;
	o.depends({transport_enabled: '1', transport_type: 'grpc'});
	o.modalonly = true;

	o = s.taboption('field_transport', form.ListValue, 'transport_xhttp_mode', _('XHTTP mode'));
	o.value('auto', _('Auto'));
	o.value('stream-one', _('stream-one'));
	o.value('stream-up', _('stream-up'));
	o.value('packet-up', _('packet-up'));
	o.depends({transport_enabled: '1', transport_type: 'xhttp'});
	o.modalonly = true;

	o = s.taboption('field_transport', form.Flag, 'transport_xhttp_no_sse_header', _('No SSE header'));
	o.default = o.disabled;
	o.depends({transport_enabled: '1', transport_type: 'xhttp'});
	o.modalonly = true;

	o = s.taboption('field_transport', form.Value, 'transport_xhttp_sc_max_buffered_posts', _('Max buffered posts'));
	o.datatype = 'uinteger';
	o.placeholder = '30';
	o.depends({transport_enabled: '1', transport_type: 'xhttp'});
	o.modalonly = true;

	o = s.taboption('field_transport', form.Value, 'transport_xhttp_sc_stream_up_server_secs', _('stream-up server seconds'));
	o.placeholder = '20-80';
	o.depends({transport_enabled: '1', transport_type: 'xhttp'});
	o.modalonly = true;

	o = s.taboption('field_transport', form.Value, 'transport_xhttp_sc_max_each_post_bytes', _('Max each POST bytes'));
	o.datatype = 'uinteger';
	o.placeholder = '1000000';
	o.depends({transport_enabled: '1', transport_type: 'xhttp'});
	o.modalonly = true;

	/* Multiplex fields */
	o = s.taboption('field_general', form.Flag, 'smux_enabled', _('Multiplex'));
	o.default = o.disabled;
	o.depends({type: /^(shadowsocks|sudoku|vmess|vless|trojan|tuic|hysteria2)$/});
	o.modalonly = true;

	o = s.taboption('field_multiplex', form.Flag, 'smux_padding', _('Enable padding'));
	o.default = o.disabled;
	o.depends('smux_enabled', '1');
	o.modalonly = true;

	o = s.taboption('field_multiplex', form.Flag, 'smux_brutal', _('Enable TCP Brutal'),
		_('Enable TCP Brutal congestion control algorithm'));
	o.default = o.disabled;
	o.depends('smux_enabled', '1');
	o.modalonly = true;

	o = s.taboption('field_multiplex', form.Value, 'smux_brutal_up', _('Upload bandwidth'),
		_('Upload bandwidth in Mbps.'));
	o.datatype = 'uinteger';
	o.depends('smux_brutal', '1');
	o.modalonly = true;

	o = s.taboption('field_multiplex', form.Value, 'smux_brutal_down', _('Download bandwidth'),
		_('Download bandwidth in Mbps.'));
	o.datatype = 'uinteger';
	o.depends('smux_brutal', '1');
	o.modalonly = true;
}

return baseclass.extend({
	/* Method */
	// render
	renderListeners,
});
