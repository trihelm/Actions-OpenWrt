#!/bin/sh

HONK_LIFECYCLE_CORE=/usr/bin/honk-core
HONK_LIFECYCLE_HAVE_TIMEOUT=$(command -v timeout 2>/dev/null)

HONK_LIFECYCLE_TICKS=1
honk_lifecycle_detect_pause() {
	HONK_LIFECYCLE_TICKS=1
	[ -n "$HONK_LIFECYCLE_HAVE_TIMEOUT" ] || return 0
	pause_before=$(cut -d' ' -f1 /proc/uptime 2>/dev/null)
	[ -n "$pause_before" ] || return 0
	timeout 0.25 sleep 1 2>/dev/null
	pause_after=$(cut -d' ' -f1 /proc/uptime 2>/dev/null)
	[ -n "$pause_after" ] || return 0
	awk -v a="$pause_before" -v b="$pause_after" 'BEGIN { exit (b - a >= 0.15) ? 0 : 1 }' && \
		HONK_LIFECYCLE_TICKS=4
	return 0
}
honk_lifecycle_detect_pause

# 字段归属：自带 global/experimental → file；只 include system.dae（且写法规范）→ system；
# 其余一律 unknown。写法不规范时不猜，直接拒绝。
# 只认顶层 include 块里的条目，控制脚本与 rpcd 共用。
config_includes_system() {
	awk '
		BEGIN { inblock = 0 }
		{
			line = $0
			sub(/\r$/, "", line)
			if (!inblock) {
				if (line ~ /^[[:space:]]*include[[:space:]]*\{/) { inblock = 1; rest = line; sub(/^[^{]*\{/, "", rest) }
				else next
			} else {
				rest = line
			}
			sub(/#.*/, "", rest)
			n = split(rest, parts, /[},]/)
			for (i = 1; i <= n; i++) {
				entry = parts[i]
				gsub(/^[[:space:]\047"]+|[[:space:]\047"]+$/, "", entry)
				if (entry == "system.dae") { print "yes"; exit }
			}
			if (line ~ /\}/) inblock = 0
		}
	' "$1"
}
config_owner() {
	config_owner_file=${1:-/etc/honk/config.dae}
	[ -f "$config_owner_file" ] && [ ! -L "$config_owner_file" ] || { echo unknown; return 0; }
	own=$(awk '/^[[:space:]]*(global|experimental)[[:space:]]*\{/ { print "1"; exit }' "$config_owner_file")
	inc=$(awk '
		{
			line = $0
			sub(/\r$/, "", line)
			if (!in_block) {
				# 只接受「include {」独占一行；同行带内容一律算不规范
				if (line ~ /^[[:space:]]*include[[:space:]]*\{[[:space:]]*$/) { in_block = 1; next }
				if (line ~ /^[[:space:]]*include[[:space:]]*\{/) { print "irregular"; next }
				next
			}
			if (line ~ /^[[:space:]]*\}[[:space:]]*$/) { in_block = 0; next }
			if (line ~ /^[[:space:]]*\}/ || line ~ /\{/) { print "irregular"; next }
			entry = line
			sub(/#.*/, "", entry)
			gsub(/^[[:space:]]+|[[:space:]]+$/, "", entry)
			gsub(/["\047]/, "", entry)
			if (entry == "") next
			if (entry == "system.dae") print "system"
			else if (entry ~ /^[A-Za-z0-9._-]+$/) print "other"
			else print "irregular"
		}
		END { if (in_block) print "irregular" }
	' "$config_owner_file")
	has_system=
	has_bad=
	case "$inc" in *system*) has_system=1 ;; esac
	case "$inc" in *other*|*irregular*) has_bad=1 ;; esac
	if [ -n "$own" ]; then
		[ -z "$inc" ] && echo file || echo unknown
	elif [ -n "$has_bad" ]; then
		echo unknown
	elif [ -n "$has_system" ]; then
		echo system
	else
		echo unknown
	fi
}

# 启动轮询用 0.25 秒粒度，核心就绪后尽快返回；没有 timeout 命令时退回 1 秒。
honk_lifecycle_pause() {
	if [ "$HONK_LIFECYCLE_TICKS" -gt 1 ]; then
		timeout 0.25 sleep 1 2>/dev/null
		return 0
	fi
	sleep 1
}

honk_lifecycle_procd_pid() {	ubus call service list '{"name":"honk"}' 2>/dev/null | jsonfilter -e '@.honk.instances.main.pid' 2>/dev/null
}

honk_lifecycle_procd_running() {
	ubus call service list '{"name":"honk"}' 2>/dev/null | jsonfilter -e '@.honk.instances.main.running' 2>/dev/null
}

honk_lifecycle_managed_pid() {
	hlp_pid=$(honk_lifecycle_procd_pid)
	[ -n "$hlp_pid" ] && [ -r "/proc/$hlp_pid/cmdline" ] || return 1
	hlp_cmd=$(tr '\000' ' ' < "/proc/$hlp_pid/cmdline" 2>/dev/null) || return 1
	case "$hlp_cmd" in
		*/usr/bin/honk-core\ --config\ /etc/honk/config.dae\ --disable-timestamp*) ;;
		*) return 1 ;;
	esac
	case "$hlp_cmd" in *--mock-ebpf*) return 1 ;; esac
	[ "$(readlink -f "/proc/$hlp_pid/exe" 2>/dev/null)" = "$HONK_LIFECYCLE_CORE" ] || return 1
	printf '%s\n' "$hlp_pid"
}

honk_lifecycle_starttime() {
	[ -r "/proc/$1/stat" ] || return 1
	awk '{ sub(/^.*\) /, ""); split($0, fields, /[[:space:]]+/); if (fields[20] ~ /^[0-9]+$/) print fields[20]; else exit 1 }' "/proc/$1/stat" 2>/dev/null
}

honk_lifecycle_listen() {
	[ -f /var/run/honk/readiness ] && [ ! -L /var/run/honk/readiness ] || return 1
	read -r hlp_token _ < /var/run/honk/readiness || return 1
	case "$hlp_token" in ''|*[!0-9a-f-]*) return 1 ;; esac
	sed -n 's/^api_listen=//p' "/var/run/honk/core-ready-$hlp_token" 2>/dev/null
}

honk_lifecycle_parse_listen() {
	HONK_LIFECYCLE_LISTEN=$(honk_lifecycle_listen)
	if [ -z "$HONK_LIFECYCLE_LISTEN" ]; then
		HONK_LIFECYCLE_PORT=0
		return 0
	fi
	case "$HONK_LIFECYCLE_LISTEN" in *:*) ;; *) return 1 ;; esac
	HONK_LIFECYCLE_PORT=${HONK_LIFECYCLE_LISTEN##*:}
	case "$HONK_LIFECYCLE_LISTEN" in ''|*[!A-Za-z0-9:._-]*) return 1 ;; esac
	case "$HONK_LIFECYCLE_PORT" in ''|*[!0-9]*) return 1 ;; esac
	[ "$HONK_LIFECYCLE_PORT" -ge 1024 ] && [ "$HONK_LIFECYCLE_PORT" -le 65535 ]
}

honk_lifecycle_ready_owned() {
	hlp_pid=$1
	[ -f /var/run/honk/readiness ] && [ ! -L /var/run/honk/readiness ] || return 1
	read -r hlp_token hlp_hash < /var/run/honk/readiness || return 1
	case "$hlp_token:$hlp_hash" in *[!0-9a-f:-]*|:*|:|*:) return 1 ;; esac
	hlp_marker=/var/run/honk/core-ready-$hlp_token
	[ -f "$hlp_marker" ] && [ ! -L "$hlp_marker" ] || return 1
	grep -Fqx "pid=$hlp_pid" "$hlp_marker" && \
		grep -Fqx "token=$hlp_token" "$hlp_marker" && \
		grep -Fqx "config_hash=$hlp_hash" "$hlp_marker" && \
		grep -Eq '^api_enabled=(true|false)$' "$hlp_marker" && \
		grep -Eq '^clash_api_secret_set=(true|false)$' "$hlp_marker"
}

honk_lifecycle_port_open() {
	hlp_port=$1
	case "$hlp_port" in ''|*[!0-9]*) return 1 ;; esac
	awk -v port="$hlp_port" 'BEGIN { printf "%04X\n", port }' | {
		IFS= read -r hlp_hex || exit 1
		for hlp_table in /proc/net/tcp /proc/net/tcp6; do
			[ -r "$hlp_table" ] || continue
			awk -v port="$hlp_hex" 'NR > 1 && toupper($2) ~ (":" port "$") && $4 == "0A" { found = 1 } END { exit !found }' "$hlp_table" && exit 0
		done
		exit 1
	}
}

honk_lifecycle_listener_owned() {
	hlp_pid=$1
	hlp_port=$2
	hlp_hex=$(awk -v port="$hlp_port" 'BEGIN { printf "%04X", port }') || return 1
	for hlp_table in /proc/net/tcp /proc/net/tcp6; do
		[ -r "$hlp_table" ] || continue
		for hlp_inode in $(awk -v port="$hlp_hex" 'NR > 1 && toupper($2) ~ (":" port "$") && $4 == "0A" { print $10 }' "$hlp_table"); do
			for hlp_fd in /proc/"$hlp_pid"/fd/*; do
				[ "$(readlink "$hlp_fd" 2>/dev/null)" = "socket:[$hlp_inode]" ] && return 0
			done
		done
	done
	return 1
}

honk_lifecycle_api_owned() {
	hlp_pid=$1
	honk_lifecycle_parse_listen || return 1
	[ "$HONK_LIFECYCLE_PORT" -gt 0 ] || return 1
	honk_lifecycle_listener_owned "$hlp_pid" "$HONK_LIFECYCLE_PORT" && \
		curl -fsS --noproxy '*' --connect-timeout 1 --max-time 2 "http://$HONK_LIFECYCLE_LISTEN/api" -o /dev/null 2>/dev/null
}

honk_lifecycle_runtime_owned() {
	honk_lifecycle_ready_owned "$1"
}

honk_lifecycle_resources_clear() {
	command -v ip >/dev/null 2>&1 || return 1
	for hlp_link in dae0 dae0peer; do
		ip link show "$hlp_link" >/dev/null 2>&1 && return 1
	done
	! ip netns list 2>/dev/null | awk '{print $1}' | grep -qx daens
}

honk_lifecycle_reclaim_resources() {
	command -v ip >/dev/null 2>&1 || return 1
	[ -z "$(pidof honk-core 2>/dev/null)" ] || return 1
	for hlp_link in dae0 dae0peer; do
		ip link show "$hlp_link" >/dev/null 2>&1 && ip link del "$hlp_link" >/dev/null 2>&1
	done
	if ip netns list 2>/dev/null | awk '{print $1}' | grep -qx daens; then
		ip netns del daens >/dev/null 2>&1
	fi
	honk_lifecycle_resources_clear
}

honk_lifecycle_drain() {
	hlp_timeout=${1:-30}
	while [ "$hlp_timeout" -gt 0 ]; do
		hlp_wait=0
		if [ -n "${HONK_LIFECYCLE_STOP_PID:-}" ] && \
			[ "$(honk_lifecycle_starttime "$HONK_LIFECYCLE_STOP_PID" 2>/dev/null)" = "$HONK_LIFECYCLE_STOP_STARTTIME" ]; then
			hlp_wait=1
		fi
		hlp_procd=$(honk_lifecycle_procd_pid)
		[ -z "$hlp_procd" ] || hlp_wait=1
		hlp_running=$(honk_lifecycle_procd_running)
		case "$hlp_running" in true|1) hlp_wait=1 ;; esac
		hlp_all=$(pidof honk-core 2>/dev/null)
		if [ -n "$hlp_all" ]; then
			for hlp_pid in $hlp_all; do
				if [ "$hlp_pid" != "${HONK_LIFECYCLE_STOP_PID:-}" ] || \
					[ "$(honk_lifecycle_starttime "$hlp_pid" 2>/dev/null)" != "${HONK_LIFECYCLE_STOP_STARTTIME:-}" ]; then
					echo "honk lifecycle: unmanaged honk-core process remains" >&2
					return 1
				fi
			done
			hlp_wait=1
		fi
		if ! honk_lifecycle_resources_clear; then
			honk_lifecycle_reclaim_resources || :
			honk_lifecycle_resources_clear || hlp_wait=1
		fi
		honk_lifecycle_parse_listen || { echo "honk lifecycle: invalid configured listener" >&2; return 1; }
		hlp_port=$HONK_LIFECYCLE_PORT
		if honk_lifecycle_port_open "$hlp_port"; then hlp_wait=1; fi
		if [ "$hlp_wait" = 0 ]; then
			return 0
		fi
		sleep 1
		hlp_timeout=$((hlp_timeout - 1))
	done
	echo "honk lifecycle: old process or network resources did not drain" >&2
	return 1
}

honk_lifecycle_stop() {
	hlp_timeout=${1:-30}
	HONK_LIFECYCLE_STOP_PID=$(honk_lifecycle_managed_pid 2>/dev/null)
	if [ -n "$HONK_LIFECYCLE_STOP_PID" ]; then
		HONK_LIFECYCLE_STOP_STARTTIME=$(honk_lifecycle_starttime "$HONK_LIFECYCLE_STOP_PID") || return 1
	else
		[ -z "$(pidof honk-core 2>/dev/null)" ] || { echo "honk lifecycle: refusing to stop unmanaged honk-core" >&2; return 1; }
		[ -z "$(honk_lifecycle_procd_pid)" ] || { echo "honk lifecycle: procd instance is not the expected core" >&2; return 1; }
		case "$(honk_lifecycle_procd_running)" in true|1) echo "honk lifecycle: procd instance is still running" >&2; return 1 ;; esac
		HONK_LIFECYCLE_STOP_STARTTIME=
	fi
	if [ -n "$HONK_LIFECYCLE_STOP_PID" ]; then /etc/init.d/honk stop >/dev/null 2>&1 || :; fi
	honk_lifecycle_drain "$hlp_timeout"
}

honk_lifecycle_start() {
	hlp_timeout=${1:-30}
	[ -z "$(pidof honk-core 2>/dev/null)" ] || { echo "honk lifecycle: refusing start while a core process exists" >&2; return 1; }
	[ -z "$(honk_lifecycle_procd_pid)" ] || { echo "honk lifecycle: procd instance has not stopped" >&2; return 1; }
	case "$(honk_lifecycle_procd_running)" in true|1) echo "honk lifecycle: procd instance is still running" >&2; return 1 ;; esac
	honk_lifecycle_resources_clear || { echo "honk lifecycle: network resources have not drained" >&2; return 1; }
	honk_lifecycle_parse_listen || { echo "honk lifecycle: invalid configured listener" >&2; return 1; }
	hlp_listen=$HONK_LIFECYCLE_LISTEN
	hlp_port=$HONK_LIFECYCLE_PORT
	if [ -n "${HONK_MAINT_CAP:-}" ]; then export HONK_MAINT_CAP; fi
	/etc/init.d/honk start >/dev/null 2>&1
	hlp_start_status=$?
	unset HONK_MAINT_CAP
	[ "$hlp_start_status" = 0 ] || { echo "honk lifecycle: init start failed" >&2; return 1; }
	hlp_stable=0
	hlp_pid=
	hlp_starttime=
	# A config the core cannot run crash-loops through procd: every attempt gets a
	# new PID, so a fixed timeout would burn the whole budget before the caller can
	# be told the start failed. Count distinct PIDs and give up early instead.
	hlp_seen_pid=
	hlp_attempts=0
	hlp_tick=0
	while [ "$hlp_timeout" -gt 0 ]; do
		hlp_new_pid=$(honk_lifecycle_managed_pid 2>/dev/null)
		if [ -n "$hlp_new_pid" ] && [ "$hlp_new_pid" != "$hlp_seen_pid" ]; then
			hlp_seen_pid=$hlp_new_pid
			hlp_attempts=$((hlp_attempts + 1))
			if [ "$hlp_attempts" -gt 3 ]; then
				echo "honk lifecycle: core keeps restarting, giving up" >&2
				return 1
			fi
		fi
		if [ -n "$hlp_new_pid" ]; then
			hlp_new_starttime=$(honk_lifecycle_starttime "$hlp_new_pid") || hlp_new_starttime=
			if [ -n "$hlp_new_starttime" ] && \
				{ [ -z "${HONK_LIFECYCLE_STOP_PID:-}" ] || [ "$hlp_new_pid:$hlp_new_starttime" != "$HONK_LIFECYCLE_STOP_PID:$HONK_LIFECYCLE_STOP_STARTTIME" ]; } && \
				{ honk_lifecycle_ready_owned "$hlp_new_pid"; }; then
				if [ "$hlp_pid:$hlp_starttime" = "$hlp_new_pid:$hlp_new_starttime" ]; then
					hlp_stable=$((hlp_stable + 1))
				else
					hlp_pid=$hlp_new_pid
					hlp_starttime=$hlp_new_starttime
					hlp_stable=1
				fi
				if [ "$hlp_stable" -ge 3 ]; then
					HONK_LIFECYCLE_STOP_PID=$hlp_new_pid
					HONK_LIFECYCLE_STOP_STARTTIME=$hlp_new_starttime
					return 0
				fi
			else
				hlp_stable=0
				hlp_pid=
				hlp_starttime=
			fi
		else
			hlp_stable=0
			hlp_pid=
			hlp_starttime=
		fi
		honk_lifecycle_pause
		hlp_tick=$((hlp_tick + 1))
		[ "$hlp_tick" -lt "$HONK_LIFECYCLE_TICKS" ] || { hlp_tick=0; hlp_timeout=$((hlp_timeout - 1)); }
	done
	echo "honk lifecycle: new managed core did not become stable and own its API listener" >&2
	return 1
}

honk_lifecycle_restart() {
	if [ -n "$(honk_lifecycle_managed_pid 2>/dev/null)" ]; then
		HONK_LIFECYCLE_WAS_RUNNING=1
	else
		[ -z "$(pidof honk-core 2>/dev/null)" ] || { echo "honk lifecycle: refusing unmanaged honk-core" >&2; return 1; }
		HONK_LIFECYCLE_WAS_RUNNING=0
	fi
	honk_lifecycle_stop "${1:-30}" && honk_lifecycle_start "${1:-30}"
}
